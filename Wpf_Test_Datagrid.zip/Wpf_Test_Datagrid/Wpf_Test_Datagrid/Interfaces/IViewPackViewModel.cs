﻿namespace Wpf_Test_Datagrid
{
    public interface IViewPackViewModel
    {
    }
}
