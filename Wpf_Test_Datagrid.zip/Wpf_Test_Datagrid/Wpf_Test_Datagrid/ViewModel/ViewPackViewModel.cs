﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using Unity;


namespace Wpf_Test_Datagrid
{
    public class ViewPackViewModel : ViewModelBase,IDialogViewModel,INotifyPropertyChanged
    {
        #region private fields 

        private ITrumpPackBLL _trumpPackBll;
        private TrumpPackModel _selectedItem;
        #endregion

        #region public properties 

        public string Title => "Choose a Pack";
        public List<TrumpPackModel> TrumpPacks
        {
            get;set;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        //SelectedItem
        public TrumpPackModel SelectedItem
        {
            get
            {
                return _selectedItem;
            }
            set
            {
                _selectedItem = value;
                OnPropertyChanged("SelectedItem");
            }
        }
        #endregion

        #region Commands
        public ICommand ViewLoaded { get; set; }
        public ICommand OkCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public event EventHandler Closed;
        #endregion

        #region ctor
        public ViewPackViewModel(ITrumpPackBLL trumpPackBll)
        {
            OkCommand = new DelegateCommand((o) => this.OnOkClick());
            CancelCommand = new DelegateCommand((o) => this.OnCancelClick());
            _trumpPackBll = trumpPackBll;
            GetTrumpPacks();

        }

        #endregion

        #region private methods

        private void OnCancelClick()
        {
            this.Closed?.Invoke(this, null);

        }

        /// <summary>
        /// Method called when ok is executed.
        /// </summary>
        /// <param name="obj"></param>
        private void OnOkClick()
        {
            try
            {
                if (SelectedItem == null)
                {
                    MessageBox.Show("You havent choosen a pack yet");
                }
                else
                {
                    this.Closed?.Invoke(this, null);
                    var dialogViewModel = VMContainer.Resolve<PackDetailViewModel>();
                    var dialogService = VMContainer.Resolve<IDialogService>();
                    dialogViewModel.SelectedItem = SelectedItem;
                    dialogService.ShowDialog(dialogViewModel, VMContainer);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
   
        /// <summary>
        /// Method to get trump packs
        /// </summary>
        private void GetTrumpPacks()
        {
            try
            {
                TrumpPacks = _trumpPackBll.GetTrumpPacks();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion


        // Create the OnPropertyChanged method to raise the event
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }


    }
}
