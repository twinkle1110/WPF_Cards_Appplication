﻿using System;
using System.Windows;
using System.Windows.Input;
using Unity;

namespace Wpf_Test_Datagrid
{
    public class MenuViewModel:ViewModelBase
    {

        #region public commands 
        public ICommand ViewPackCommand { get; set; }
        public ICommand ExitCommand { get; set; }
        #endregion

        #region ctor
        public MenuViewModel()
        {
            ViewPackCommand = new DelegateCommand((o) => this.OnViewPackClick(o));
            ExitCommand = new DelegateCommand((o) => this.OnExitCommand(o));
        }

        #endregion

        #region private Methods
        /// <summary>
        /// Method to View Packs
        /// </summary>
        /// <returns></returns>
        private void OnViewPackClick(object win)
        {
            try
            {
                ((Window)win).Hide();
                var dialogViewModel = VMContainer.Resolve<ViewPackViewModel>();
                var dialogService = VMContainer.Resolve<IDialogService>();
                dialogService.ShowDialog(dialogViewModel, VMContainer);
                ((Window)win).Show();
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
}

        /// <summary>
        /// Method to exit menu.
        /// </summary>
        /// <returns></returns>
        private void OnExitCommand(object win)
        {
            ((Window)win).Close();

        }



        #endregion
    }
}
