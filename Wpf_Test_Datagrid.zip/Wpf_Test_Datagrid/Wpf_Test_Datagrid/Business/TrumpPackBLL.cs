﻿
using System.Collections.Generic;


namespace Wpf_Test_Datagrid
{
    public class TrumpPackBll:ITrumpPackBLL
    {
        ITrumpPackService _trumpPackService;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="trumpPackBll"></param>
        public TrumpPackBll(ITrumpPackService trumpPackService)
        {
            _trumpPackService = trumpPackService;
        }

        /// <summary>
        /// Method to get trump pack.
        /// </summary>
        /// <returns></returns>
        public List<TrumpPackModel> GetTrumpPacks()
        {
            return _trumpPackService.GetTrumpPacks();
        }

        /// <summary>
        /// /// Method to get card details
        /// </summary>
        /// <param name="packId"></param>
        /// <returns></returns>
        public List<CardDetailModel> GetCardDetails(int packId)
        {
            return _trumpPackService.GetCardDetails(packId);
        }

  
    }
}
