﻿using DataAccessLayer;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Service_New
{

    public class TrumpPackService : ITrumpPackService
    {
        private IConnectionFactory connectionFactory;
        /// <summary>
        /// Method to get trump packs
        /// </summary>
        /// <returns></returns>
        public List<TrumpPackDTO> GetTrumpPacks()
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var trumpPackRep = new TrumpPackRepository(context);

            return trumpPackRep.GetTrumpPacks().ToList();
        }

        /// <summary>
        /// Method to get card details
        /// </summary>
        /// <returns></returns>
        public List<CardDetailsDTO> GetCardDetails(int packId)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var cardDetailRep = new CardDetailRepository(context);

            return cardDetailRep.GetCardDetails(packId).ToList();
        }


    }
}
