﻿using System.Windows.Controls;

namespace Wpf_Test_Datagrid
{
    /// <summary>
    /// Interaction logic for ViewPacks.xaml
    /// </summary>
    public partial class ViewPacks : UserControl
    {
        public ViewPacks()
        {
            InitializeComponent();
        }


    }
   
}