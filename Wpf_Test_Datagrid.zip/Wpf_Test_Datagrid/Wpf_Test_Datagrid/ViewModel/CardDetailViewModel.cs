﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
namespace Wpf_Test_Datagrid
{
    class CardDetailViewModel : ViewModelBase, IDialogViewModel, INotifyPropertyChanged
    {
        #region private fields 

        private ITrumpPackBLL _trumpPackBll;
        private int _packId;
        private int _selectedIndex;
        private CardDetailModel _selectedItem;
        #endregion

        #region public properties 

        public string Title => "Animals Top Trump Cards";

        public event PropertyChangedEventHandler PropertyChanged;
        /// <summary>
        /// PackId
        /// </summary>
        public int PackId 
        {
            get
            {
                return _packId;
            }
            set
            {
                _packId = value;
                GetCardDetailsForAPack(_packId);
            }
        }
        /// <summary>
        /// Cards
        /// </summary>
        public List<CardDetailModel> Cards { get; set; }
        /// <summary>
        /// Categories
        /// </summary>
        public List<CardDetailModel> Categories { get; set; }
        /// <summary>
        /// SelectedItem
        /// </summary>
        public CardDetailModel SelectedItem
        {
            get
            {
                return _selectedItem;
            }
            set
            {
                _selectedItem = value;
                OnPropertyChanged("SelectedItem");
                CreateScoreCategories();
            }
        }
        /// <summary>
        /// SelectedIndex
        /// </summary>
        public int SelectedIndex
        {
            get { return _selectedIndex; }
            set { _selectedIndex = value; OnPropertyChanged("SelectedIndex"); }
        }


        #endregion

        #region Commands
        public ICommand PreviousCommand { get; set; }
        public ICommand NextCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public event EventHandler Closed;
        #endregion

        #region ctor
        public CardDetailViewModel(ITrumpPackBLL trumpPackBll)
        {
            PreviousCommand = new DelegateCommand((o) => this.OnPrevious());
            NextCommand = new DelegateCommand((o) => this.OnNext());
            CancelCommand = new DelegateCommand((o) => this.OnCancelClick());
            _trumpPackBll = trumpPackBll;           
        }
 
        #endregion

        #region private methods
        /// <summary>
        /// Method called when cancel is clicked.
        /// </summary>
        /// <param name="win"></param>
        private void OnCancelClick()
        {
            if (this.Closed != null)
            {
                this.Closed(this, null);
            }

        }

        /// <summary>
        /// Method to get trump packs
        /// </summary>
        private void GetCardDetailsForAPack(int packId)
        {
            try
            {
                Cards = _trumpPackBll.GetCardDetails(packId);
                SelectedItem = Cards[SelectedIndex];
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        /// <summary>
        /// Method on next button.
        /// </summary>
        private void OnNext()
        {
            try
            {
                if (SelectedIndex != Cards.Count-1)
                SelectedIndex += 1;
                if (Cards.ElementAtOrDefault(SelectedIndex)!= null)
                {
                    SelectedItem = Cards[SelectedIndex];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Method on previous button.
        /// </summary>
        private void OnPrevious()
        {
            try
            {
                if (SelectedIndex != 0 )
                    SelectedIndex -= 1;
                if (Cards.ElementAtOrDefault(SelectedIndex) != null)
                {
                    SelectedItem = Cards[SelectedIndex];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Method to created categories when selecteditem changed.
        /// </summary>
        private void CreateScoreCategories()
        {
            var item = Cards?.FirstOrDefault(x => x.CardId == SelectedItem.CardId);
            if (item != null)
            {
                Categories = new List<CardDetailModel>(){new CardDetailModel() { Category1 = item.Category1, Score1 = item.Score1 },
                            new CardDetailModel() { Category1 = item.Category2, Score1 = item.Score2 },
                            new CardDetailModel() { Category1 = item.Category3, Score1 = item.Score3 },
                            new CardDetailModel() { Category1 = item.Category4, Score1 = item.Score4 } };
            }
        }
     
        // Create the OnPropertyChanged method to raise the event
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
    #endregion


    

