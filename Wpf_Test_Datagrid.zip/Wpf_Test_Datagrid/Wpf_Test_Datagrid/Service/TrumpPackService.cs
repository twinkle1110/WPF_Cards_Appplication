﻿using AutoMapper;
using Models;
using System.Collections.Generic;
using System.Linq;

namespace Wpf_Test_Datagrid
{
    public class TrumpPackService : ITrumpPackService
    {

        /// <summary>
        /// Method to get trump packs
        /// </summary>
        /// <returns></returns>
        public List<TrumpPackModel> GetTrumpPacks()
        {         
            List<TrumpPackModel> packs;           
            using (var client = new TrumpPackServiceClient.TrumpPackServiceClient())
            {
                var trumpPacks= client.GetTrumpPacks().ToList();
                packs = Mapper.Map<List<TrumpPackDTO>,List<TrumpPackModel>>(trumpPacks);
            }
            return packs;
        }

        /// <summary>
        /// Method to get card details.
        /// </summary>
        /// <returns></returns>
        public List<CardDetailModel> GetCardDetails(int packId)
        {
            List<CardDetailModel> cards;
            using (var client = new TrumpPackServiceClient.TrumpPackServiceClient())
            {
                var cardDetails = client.GetCardDetails(packId).ToList();
                cards = Mapper.Map<List<CardDetailsDTO>, List<CardDetailModel>>(cardDetails);
            }
            return cards;
        }

    }
}
