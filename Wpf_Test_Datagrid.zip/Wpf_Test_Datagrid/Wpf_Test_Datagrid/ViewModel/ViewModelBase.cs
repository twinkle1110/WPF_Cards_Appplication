﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Unity;

namespace Wpf_Test_Datagrid
{
    public class ViewModelBase
    {
        /// <summary>
        /// VMContainer
        /// </summary>
        public UnityContainer VMContainer
        {
            get
            {
               return (UnityContainer)Application.Current.Resources["IoC"];
            }
        }
    }
}
