﻿
using AutoMapper;
using System.Windows;
using Unity;
using Unity.Lifetime;

namespace Wpf_Test_Datagrid
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private IUnityContainer _container;
        public IUnityContainer Container
        {
            get
            {
                if (_container == null)
                {
                    _container = new UnityContainer();

                }
                return _container;
            }
        }
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            Container.RegisterType<IDialogService,DialogService>();
            Container.RegisterType<ITrumpPackBLL, TrumpPackBll>();
            Container.RegisterType<ITrumpPackService, TrumpPackService>();
            var menuViewModel = Container.Resolve<MenuViewModel>();
            Mapper.Initialize(c => c.AddProfile<MappingProfile>());
            Application.Current.Resources.Add("IoC", this.Container);
            var window = new Menu { DataContext = menuViewModel };
            window.Show();
        }
    }
}
