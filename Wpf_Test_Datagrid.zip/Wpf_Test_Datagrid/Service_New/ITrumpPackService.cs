﻿using Models;
using System.Collections.Generic;
using System.ServiceModel;

namespace Service_New
{
    [ServiceContract]
    public interface ITrumpPackService
    {
        [OperationContract]
        List<TrumpPackDTO> GetTrumpPacks();
        [OperationContract]
        List<CardDetailsDTO> GetCardDetails(int packId);
    }
}
