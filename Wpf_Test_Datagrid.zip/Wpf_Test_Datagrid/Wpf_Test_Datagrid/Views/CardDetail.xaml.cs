﻿using System.Windows.Controls;

namespace Wpf_Test_Datagrid.Views
{
    /// <summary>
    /// Interaction logic for CardDetail.xaml
    /// </summary>
    public partial class CardDetail : UserControl
    {
        public CardDetail()
        {
            InitializeComponent();
        }
    }
}
