﻿using AutoMapper;
using Models;

namespace Wpf_Test_Datagrid
{
    public  class MappingProfile :Profile
    {
   
    public MappingProfile()
    {
        CreateMap<TrumpPackDTO, TrumpPackModel>();
        
    }            
    
    }
}
