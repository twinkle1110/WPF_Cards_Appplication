﻿namespace Wpf_Test_Datagrid
{
    public interface IPackDetailViewModel
    {
         TrumpPackModel SelectedItem { get; set; }
    }
}
