﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Unity;

namespace Wpf_Test_Datagrid
{

    public class DialogService : IDialogService
    {
        #region constants
        private const string ViewModelConstant = "ViewModel";
        private IUnityContainer container;
        #endregion
        public void ShowDialog<T>(T context, IUnityContainer unityContainer) where T : IDialogViewModel
        {
            container = unityContainer;
            Invoke(context, null);
           
        }
        private void Invoke<T>(T dialogViewModel, Action<T> callback, WindowState windowState = WindowState.Normal) where T : IDialogViewModel
        {
            Window wrapperWindow = GetWindow(dialogViewModel, windowState);
            EventHandler viewModelClosedHandler = (sender, e) => wrapperWindow.Close();
            dialogViewModel.Closed += viewModelClosedHandler;

            // We invoke the callback when the interaction's window is closed.
            EventHandler windowClosedHandler = null;

            windowClosedHandler =
                (sender, e) =>
                {
                    wrapperWindow.Closed -= windowClosedHandler;
                    dialogViewModel.Closed -= viewModelClosedHandler;

                    if (wrapperWindow.Owner != null && wrapperWindow.Owner is Window)
                    {
                        (wrapperWindow.Owner as Window).Activate();
                    }
                    wrapperWindow.Content = null;
                    if (callback != null) callback(dialogViewModel);
                };

            wrapperWindow.Closed += windowClosedHandler;

            wrapperWindow.ShowDialog();
        }
        private Window GetWindow(IDialogViewModel dialogViewModel, WindowState windowState)
        {
            Window wrapperWindow = new Window
            {
                Title = dialogViewModel.Title,
                ShowInTaskbar = true,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                WindowState = windowState
            };

            if (windowState != WindowState.Maximized)
            {
                wrapperWindow.SizeToContent = System.Windows.SizeToContent.WidthAndHeight;
                wrapperWindow.ShowInTaskbar = false;
                wrapperWindow.ResizeMode = ResizeMode.NoResize;
                wrapperWindow.BorderBrush = Brushes.Black;
                wrapperWindow.BorderThickness = new Thickness(2);
                wrapperWindow.WindowStyle = WindowStyle.None;
                wrapperWindow.MouseDown += WrapperWindow_MouseDown;
            }

            Window mainWindow = System.Windows.Application.Current.MainWindow;

            if (mainWindow != null && mainWindow != wrapperWindow)
            {
                wrapperWindow.Owner = mainWindow;
                wrapperWindow.Icon = mainWindow.Icon;
            }

            var viewType = (from t in dialogViewModel.GetType().Assembly.GetTypes()
                            where t.IsClass
                            && t.BaseType == typeof(UserControl)
                            && t.Name.StartsWith(dialogViewModel.GetType().Name.Replace(ViewModelConstant, string.Empty))
                            select t).First();

            FrameworkElement view = container.Resolve(viewType) as FrameworkElement;
            view.DataContext = dialogViewModel;
            wrapperWindow.Content = view;
            return wrapperWindow;
        }

        private void WrapperWindow_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var window = sender as Window;
            if (e.ChangedButton == MouseButton.Left)
            {
                window.DragMove();
            }
        }
    }
    public interface IDialogViewModel
    {
        string Title { get; }
        event EventHandler Closed;

        
    }
    public interface IDialogService
    {
        void ShowDialog<T>(T context, IUnityContainer unityContainer) where T : IDialogViewModel;
       
    }
}
