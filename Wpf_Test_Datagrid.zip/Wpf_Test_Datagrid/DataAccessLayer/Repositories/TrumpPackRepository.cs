﻿using Models;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace DataAccessLayer
{
    public class TrumpPackRepository : Repository<TrumpPackDTO>
    {
        private DbContext _context;
        public TrumpPackRepository(DbContext context)
            : base(context)
        {
            _context = context;
        }

        /// <summary>
        /// Method to get trump packs
        /// </summary>
        /// <returns></returns>
        public IList<TrumpPackDTO> GetTrumpPacks()
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = "Select * from tblPack";
                return this.ToList(command).ToList();
            }
        }
    }
}
