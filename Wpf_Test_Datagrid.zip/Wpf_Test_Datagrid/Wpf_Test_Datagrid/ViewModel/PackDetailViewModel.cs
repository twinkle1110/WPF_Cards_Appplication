﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using Unity;

namespace Wpf_Test_Datagrid
{
    class PackDetailViewModel: ViewModelBase, IDialogViewModel, INotifyPropertyChanged
    {
        #region private fields 
        private TrumpPackModel selectedItem;

        #endregion

        #region public properties 

        public string Title => "Animals Pack";
       
        public event PropertyChangedEventHandler PropertyChanged;
        /// <summary>
        /// Categories
        /// </summary>
        public List<TrumpPackModel> Categories{ get; set; }
        /// <summary>
        /// SelectedItem
        /// </summary>
        public TrumpPackModel SelectedItem
        {
            get
            {
                return selectedItem;
            }
            set
            {
                selectedItem = value;
               CreateCategories();
            }
        }

        #endregion

        #region Commands

        public ICommand ShowCardCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public event EventHandler Closed;
        #endregion

        #region ctor
        public PackDetailViewModel(ITrumpPackBLL trumpPackBll)
        {
            ShowCardCommand = new DelegateCommand((o) => this.OnShowCardClick());
            CancelCommand = new DelegateCommand((o) => this.OnCancelClick());                   
        }

        #endregion

        #region private methods

        private void OnCancelClick()
        {
            this.Closed?.Invoke(this, null);
        }

        /// <summary>
        /// Method called when show card is executed.
        /// </summary>
        /// <param name="obj"></param>
        private void OnShowCardClick()
        {
            try
            {
                this.Closed?.Invoke(this, null);
                var dialogViewModel = VMContainer.Resolve<CardDetailViewModel>();
                var dialogService = VMContainer.Resolve<IDialogService>();
                dialogViewModel.PackId = SelectedItem.PackId;

                dialogService.ShowDialog(dialogViewModel, VMContainer);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    

        /// <summary>
        /// Method to createCategories
        /// </summary>
        private void CreateCategories()
        {
            if (SelectedItem != null)
            {
                Categories = new List<TrumpPackModel>() { new TrumpPackModel() { SerialNo = 1, PackId = SelectedItem.PackId,
                    Category1 = SelectedItem.Category1 },new TrumpPackModel() { SerialNo = 2, PackId = SelectedItem.PackId, Category1 = SelectedItem.Category2 },
                    new TrumpPackModel() { SerialNo = 3, PackId = SelectedItem.PackId, Category1 = SelectedItem.Category3 },
                    new TrumpPackModel() { SerialNo = 4, PackId = SelectedItem.PackId, Category1 = SelectedItem.Category4 } };

               
            }
        }

        #endregion


        // Create the OnPropertyChanged method to raise the event
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
