﻿using Models;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace DataAccessLayer
{
    public class CardDetailRepository : Repository<CardDetailsDTO>
    {
        private DbContext _context;
        public CardDetailRepository(DbContext context)
            : base(context)
        {
            _context = context;
        }

        /// <summary>
        /// Method to get trump packs
        /// </summary>
        /// <returns></returns>
        public IList<CardDetailsDTO> GetCardDetails(int packId)
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = "Select * from vwCard where packid = "+ packId;
                return this.ToList(command).ToList();
            }
        }
    }
}
