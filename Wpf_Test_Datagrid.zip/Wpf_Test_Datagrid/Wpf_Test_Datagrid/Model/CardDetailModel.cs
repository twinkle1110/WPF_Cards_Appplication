﻿namespace Wpf_Test_Datagrid
{
    public class CardDetailModel
    {
        public int PackId { get; set; }

        public int CardId { get; set; }

        public string CardTitle { get; set; }

        public string ImageName { get; set; }
        public string PackName { get; set; }

        public string Description { get; set; }

        public string Category1 { get; set; }

        public string Category2 { get; set; }

        public string Category3 { get; set; }
        public string Category4 { get; set; }

        public int Score1 { get; set; }

        public int Score2 { get; set; }

        public int Score3 { get; set; }
        public int Score4 { get; set; }
        public string ImageNameAbsolute
        {
            get
            {
                return string.Format("pack://application:,,,/Resources/{0}", ImageName);
            }
        }
    }
}
