﻿using System.Collections.Generic;

namespace Wpf_Test_Datagrid
{
    public interface ITrumpPackService
    {
        List<TrumpPackModel> GetTrumpPacks();
        List<CardDetailModel> GetCardDetails(int packId);
    }
}
