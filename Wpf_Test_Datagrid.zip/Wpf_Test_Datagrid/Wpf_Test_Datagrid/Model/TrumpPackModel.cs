﻿using AutoMapper;
using Models;

namespace Wpf_Test_Datagrid
{

    public class TrumpPackModel
    {
        public int PackId { get; set; }
       
        public string PackName { get; set; }
        public string DesignImage { get; set; }
        public string PackImageTest
        {
            get
            {
                return string.Format("pack://application:,,,/Resources/{0}", DesignImage);
            }
        }
        /// <summary>
        /// Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Category1
        /// </summary>
        public string Category1 { get; set; }

        /// <summary>
        /// Category2
        /// </summary>
        public string Category2 { get; set; }
        /// <summary>
        /// Category3
        /// </summary>
        public string Category3 { get; set; }
        /// <summary>
        /// Category4
        /// </summary>
        public string Category4 { get; set; }

        public int SerialNo { get; set; }

    }
}
