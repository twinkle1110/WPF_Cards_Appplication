﻿using System.Windows.Controls;

namespace Wpf_Test_Datagrid
{
    /// <summary>
    /// Interaction logic for PackDetails.xaml
    /// </summary>
    public partial class PackDetails : UserControl
    {
        public PackDetails()
        {
            InitializeComponent();
        }
    }
}
